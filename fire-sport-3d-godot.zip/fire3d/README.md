# Fire Sport 3D (Godot 4.3+) - Phase 1-2 slice
Open this folder in Godot 4.3+ (Import project.godot), press F5.
Controls: WASD move, Shift sprint, mouse look (click to capture), Space start, E connect, LMB spray, R restart, Esc free mouse.
Goal: connect C1, PUMP, C2, C3, C4 in order (wrong one = +5 s), then run to the targets with the hose tethered to the divider and hit both with the water stream.
Fictional course; order and penalty are game assumptions, not official rules.
