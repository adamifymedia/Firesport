extends Node3D
## Fire Sport 3D - Phase 1-2 vertical slice. All geometry is procedural (no assets).
## Fictional course. Connection order and penalties are game assumptions, not official rules.

const PEN := 5.0
const TETHER := 30.0
const RANGE := 13.0
const SEQ := ["C1", "PUMP", "C2", "C3", "C4"]
const DIV := Vector3(0, 0.6, 0)
const TANK := Vector3(-17, 0.6, 6)
const PTS := {"C1": Vector3(-14, 0.6, 6), "PUMP": Vector3(-10, 0.6, -2), "C2": Vector3(-2, 0.6, 0), "C3": Vector3(2, 0.6, -3), "C4": Vector3(2, 0.6, 3)}
const TGT := {"L": Vector3(26, 1.3, -8), "R": Vector3(26, 1.3, 8)}
const HOSE_NEED := {"C1": ["C1"], "C2": ["C1", "C2"], "C3": ["C1", "C2", "C3"], "C4": ["C1", "C2", "C4"]}

var attr := {"spd": 70, "acc": 65, "end": 60, "noz": 60, "prec": 60}  # selected firefighter (placeholder until career data is wired in)
var body: CharacterBody3D
var pivot: Node3D
var spring: SpringArm3D
var cam: Camera3D
var info: Label
var hint: Label
var cross: ColorRect
var stream: MeshInstance3D
var live_hose: MeshInstance3D
var hoses: Array = []
var marks := {}
var tmesh := {}
var conn := {}
var down := {}
var prog := {"L": 0.0, "R": 0.0}
var splits: Array = []
var state := 0  # 0 idle, 1 waiting for signal, 2 running
var go_at := 0
var clock := 0.0
var pen := 0.0
var step := 0
var pump_on := false
var finished := false
var yaw := 0.0
var pitch := -0.25
var stam := 1.0
var wob_t := 0.0
var msg := ""
var msg_t := 0.0

func mat(c: Color) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    return m

func box(pos: Vector3, size: Vector3, c: Color, solid := false) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = mat(c)
    mi.position = pos
    add_child(mi)
    if solid:
        var sb := StaticBody3D.new()
        var cs := CollisionShape3D.new()
        var bs := BoxShape3D.new()
        bs.size = size
        cs.shape = bs
        sb.add_child(cs)
        mi.add_child(sb)
    return mi

func mk_cyl(r: float, c: Color) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = r
    cm.bottom_radius = r
    mi.mesh = cm
    mi.material_override = mat(c)
    add_child(mi)
    return mi

func set_cyl(m: MeshInstance3D, a: Vector3, b: Vector3) -> void:
    var d := a.distance_to(b)
    if d < 0.05:
        m.visible = false
        return
    m.visible = true
    (m.mesh as CylinderMesh).height = d
    var up := Vector3.UP
    if absf((b - a).normalized().y) > 0.99:
        up = Vector3.RIGHT
    m.look_at_from_position((a + b) * 0.5, b, up)
    m.rotate_object_local(Vector3.RIGHT, PI / 2.0)

func _ready() -> void:
    var we := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_COLOR
    e.background_color = Color(0.55, 0.75, 0.95)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.7, 0.7, 0.75)
    we.environment = e
    add_child(we)
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -30, 0)
    add_child(sun)
    box(Vector3(0, -0.5, 0), Vector3(90, 1, 50), Color(0.25, 0.55, 0.25), true)
    box(Vector3(-12, 0.01, 0), Vector3(30, 0.02, 20), Color(0.6, 0.6, 0.62))
    box(Vector3(-20, 0.03, 0), Vector3(0.3, 0.02, 14), Color.WHITE)
    box(Vector3(-10, 0.5, -3.8), Vector3(1.6, 1.0, 1.2), Color(0.8, 0.15, 0.15), true)
    box(Vector3(-18, 0.6, 6), Vector3(2.4, 1.2, 2.4), Color(0.2, 0.4, 0.8), true)
    box(DIV + Vector3(0, -0.2, 0), Vector3(0.8, 0.8, 0.8), Color(0.9, 0.7, 0.1))
    for i in range(14):
        box(Vector3(-40 + i * 6, 0.8, -23), Vector3(1, 1.6, 1), Color.from_hsv(fmod(i * 0.13, 1.0), 0.5, 0.9))
    for i in range(5):
        box(Vector3(-36 + i * 18, 4, -32), Vector3(10, 8, 6), Color(0.6, 0.5, 0.45), true)
    for k in PTS:
        var s := MeshInstance3D.new()
        var sm := SphereMesh.new()
        sm.radius = 0.35
        sm.height = 0.7
        s.mesh = sm
        s.material_override = mat(Color.GRAY)
        s.position = PTS[k]
        add_child(s)
        marks[k] = s
    for k in TGT:
        var tb := StaticBody3D.new()
        tb.position = TGT[k]
        tb.rotation_degrees = Vector3(0, 0, 90)
        tb.set_meta("tgt", k)
        var cs := CollisionShape3D.new()
        var sh := CylinderShape3D.new()
        sh.radius = 0.8
        sh.height = 0.1
        cs.shape = sh
        tb.add_child(cs)
        var tm := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        cm.top_radius = 0.8
        cm.bottom_radius = 0.8
        cm.height = 0.1
        tm.mesh = cm
        tm.material_override = mat(Color(0.85, 0.15, 0.15))
        tb.add_child(tm)
        add_child(tb)
        tmesh[k] = tm
    body = CharacterBody3D.new()
    body.position = Vector3(-22, 0.1, 4)
    add_child(body)
    var pcs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.35
    cap.height = 1.8
    pcs.shape = cap
    pcs.position.y = 0.9
    body.add_child(pcs)
    var pm := MeshInstance3D.new()
    var pcm := CapsuleMesh.new()
    pcm.radius = 0.35
    pcm.height = 1.8
    pm.mesh = pcm
    pm.material_override = mat(Color(1.0, 0.5, 0.1))
    pm.position.y = 0.9
    body.add_child(pm)
    pivot = Node3D.new()
    pivot.top_level = true
    add_child(pivot)
    spring = SpringArm3D.new()
    spring.spring_length = 5.0
    spring.margin = 0.2
    spring.add_excluded_object(body.get_rid())
    pivot.add_child(spring)
    cam = Camera3D.new()
    spring.add_child(cam)
    stream = mk_cyl(0.04, Color(0.3, 0.7, 1.0))
    stream.visible = false
    live_hose = mk_cyl(0.08, Color(0.8, 0.2, 0.2))
    live_hose.visible = false
    var cl := CanvasLayer.new()
    add_child(cl)
    info = Label.new()
    info.position = Vector2(14, 10)
    cl.add_child(info)
    hint = Label.new()
    cl.add_child(hint)
    cross = ColorRect.new()
    cross.size = Vector2(6, 6)
    cross.color = Color(1, 1, 1, 0.8)
    cl.add_child(cross)

func flash(t: String) -> void:
    msg = t
    msg_t = 2.5

func key(k: Key) -> bool:
    return Input.is_physical_key_pressed(k)

func nearest() -> String:
    for k in PTS:
        var p: Vector3 = PTS[k]
        if Vector2(body.position.x - p.x, body.position.z - p.z).length() < 1.8:
            return k
    return ""

func begin() -> void:
    if state == 0 and not finished:
        state = 1
        go_at = Time.get_ticks_msec() + randi_range(1500, 3300)
        flash("Wait for the signal... do not move!")

func add_hose(a: Vector3, b: Vector3, k: String) -> void:
    var m := mk_cyl(0.08, Color(0.8, 0.2, 0.2))
    set_cyl(m, a, b)
    hoses.append({"m": m, "need": HOSE_NEED[k]})

func interact() -> void:
    if state != 2 or finished or step >= SEQ.size():
        return
    var n := nearest()
    if n == "":
        return
    if n != SEQ[step]:
        pen += PEN
        flash("Wrong connection (%s)! +%d s" % [n, int(PEN)])
        return
    conn[n] = true
    splits.append("%s %.2f s" % [n, clock])
    step += 1
    match n:
        "PUMP":
            pump_on = true
        "C1":
            add_hose(TANK, PTS["PUMP"], "C1")
        "C2":
            add_hose(PTS["PUMP"], DIV, "C2")
        "C3":
            add_hose(DIV, PTS["C3"], "C3")
        "C4":
            add_hose(DIV, PTS["C4"], "C4")

func knock(k: String) -> void:
    down[k] = true
    (tmesh[k].material_override as StandardMaterial3D).albedo_color = Color(0.2, 0.8, 0.3)
    splits.append("Target %s %.2f s" % [k, clock])
    flash("Target %s hit!" % k)
    if down.size() == 2:
        finished = true

func spray(dt: float) -> void:
    if not pump_on:
        flash("No water!")
        return
    wob_t += dt
    var w := (100.0 - float(attr["noz"])) * 0.0006
    var bs := pivot.global_transform.basis
    var dir := (-bs.z).rotated(Vector3.UP, sin(wob_t * 7.0) * w).rotated(bs.x, cos(wob_t * 5.0) * w)
    var from := pivot.global_position + dir * 0.8
    var to := from + dir * RANGE
    var q := PhysicsRayQueryParameters3D.create(from, to)
    q.exclude = [body.get_rid()]
    var h := get_world_3d().direct_space_state.intersect_ray(q)
    var end := to
    if h:
        end = h["position"]
        var c: Object = h["collider"]
        if c.has_meta("tgt"):
            var k: String = c.get_meta("tgt")
            if not down.has(k):
                prog[k] += dt / (1.1 - float(attr["prec"]) / 200.0)
                if prog[k] >= 1.0:
                    knock(k)
    set_cyl(stream, from, end)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
        yaw -= event.relative.x * 0.003
        pitch = clampf(pitch - event.relative.y * 0.003, -1.2, 0.4)
    elif event is InputEventMouseButton and event.pressed:
        Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
    elif event is InputEventKey and event.pressed and not event.echo:
        match event.keycode:
            KEY_E:
                interact()
            KEY_SPACE:
                begin()
            KEY_R:
                get_tree().reload_current_scene()
            KEY_ESCAPE:
                Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _physics_process(dt: float) -> void:
    var mv := Vector2(float(key(KEY_D)) - float(key(KEY_A)), float(key(KEY_S)) - float(key(KEY_W)))
    if state == 1:
        if mv.length() > 0.1:
            pen += PEN
            state = 0
            flash("False start! +%d s. Press SPACE to retry." % int(PEN))
        elif Time.get_ticks_msec() >= go_at:
            state = 2
            clock = 0.0
            flash("GO!")
    var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
    var right := Vector3(cos(yaw), 0, -sin(yaw))
    var dir := right * mv.x - fwd * mv.y
    if dir.length() > 1.0:
        dir = dir.normalized()
    var sprint := key(KEY_SHIFT) and stam > 0.05 and dir.length() > 0.1
    var vmax := (4.0 + float(attr["spd"]) * 0.04) * (1.5 if sprint else 1.0) * (0.75 + 0.25 * stam)
    if sprint:
        stam = maxf(0.0, stam - dt * 0.08 * (1.3 - float(attr["end"]) / 100.0))
    else:
        stam = minf(1.0, stam + dt * 0.03)
    var hv := Vector3(body.velocity.x, 0, body.velocity.z).move_toward(dir * vmax, (12.0 + float(attr["acc"]) * 0.2) * dt)
    body.velocity.x = hv.x
    body.velocity.z = hv.z
    body.velocity.y = 0.0 if body.is_on_floor() else body.velocity.y - 20.0 * dt
    body.move_and_slide()
    if dir.length() > 0.1:
        body.rotation.y = lerp_angle(body.rotation.y, atan2(-dir.x, -dir.z), 10.0 * dt)
    if state == 2 and not finished:
        clock += dt
    pivot.global_position = body.global_position + Vector3(0, 1.6, 0)
    pivot.rotation = Vector3(pitch, yaw, 0)
    stream.visible = false
    for k in prog:
        if not down.has(k):
            prog[k] = maxf(0.0, prog[k] - dt * 0.5)
    if step >= SEQ.size():
        var off := Vector2(body.position.x - DIV.x, body.position.z - DIV.z)
        if off.length() > TETHER:
            off = off.normalized() * TETHER
            body.position.x = DIV.x + off.x
            body.position.z = DIV.z + off.y
        set_cyl(live_hose, DIV, body.global_position + Vector3(0, 1.0, 0))
        (live_hose.material_override as StandardMaterial3D).albedo_color = Color(0.2, 0.6, 1.0) if pump_on else Color(0.8, 0.2, 0.2)
        if state == 2 and not finished and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
            spray(dt)

func _process(dt: float) -> void:
    msg_t = maxf(0.0, msg_t - dt)
    var vs := get_viewport().get_visible_rect().size
    cross.position = vs / 2.0 - Vector2(3, 3)
    hint.position = Vector2(vs.x / 2.0 - 160, vs.y - 70)
    for h in hoses:
        var ok: bool = pump_on
        for n in h["need"]:
            ok = ok and conn.has(n)
        (h["m"].material_override as StandardMaterial3D).albedo_color = Color(0.2, 0.6, 1.0) if ok else Color(0.8, 0.2, 0.2)
    for k in marks:
        var c := Color.GRAY
        if conn.has(k):
            c = Color(0.2, 0.9, 0.4)
        elif state == 2 and not finished and step < SEQ.size() and SEQ[step] == k:
            c = Color(1, 0.9, 0.2) * (0.7 + 0.3 * sin(Time.get_ticks_msec() * 0.01))
        (marks[k].material_override as StandardMaterial3D).albedo_color = c
    var nxt := "Aim at both targets: hold left mouse (run closer, range %d m)" % int(RANGE)
    if step < SEQ.size():
        nxt = "Next: " + SEQ[step]
    var s := "Time %.2f s   +%d s penalties   Stamina %d%%\n%s\n" % [clock, int(pen), int(stam * 100.0), nxt]
    if state == 0:
        s += "Press SPACE to get set, then wait for GO\n"
    if finished:
        s += "FINISH %.2f s  (%.2f + %d s)\n%s\nPress R to retry\n" % [clock + pen, clock, int(pen), ", ".join(splits)]
    s += "WASD move | Shift sprint | Mouse look (click to capture, Esc to release) | E connect | LMB spray | R restart"
    info.text = s
    var n := nearest()
    if msg_t > 0.0:
        hint.text = msg
    elif n != "" and state == 2 and not finished and step < SEQ.size():
        hint.text = "[E] Connect " + n
    else:
        hint.text = ""
